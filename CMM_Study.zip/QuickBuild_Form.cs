﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Cognex.VisionPro.QuickBuild;

namespace CMM_Study
{
    public partial class QuickBuild_Form : Form
    {
        CMM_Study.CMM_Study_Form mainRef;
        
        public QuickBuild_Form(CMM_Study.CMM_Study_Form main, CogJobManager mJobManager)
        {
            InitializeComponent();

            mainRef = main;

            this.cogJobManagerEdit.Subject = mJobManager;
        }
    }
}
