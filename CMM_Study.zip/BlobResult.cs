﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CMM_Study
{
   class BlobResult
    {
        public double CenterX { get; set; }
        public double CenterY { get; set; }
    }
}
