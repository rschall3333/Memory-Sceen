﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Cognex.VisionPro;
using Cognex.VisionPro.QuickBuild;
using Cognex.VisionPro.ToolGroup;
using Cognex.VisionPro.Blob;
using System.Threading;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Windows.Forms;

namespace CMM_Study
{
    class QuickbuildManager : IDisposable
    {
        bool disposed;
        public string currentJobName;
        public bool runCountinuous = false;
        public string imageSaveDescription = "Nothing";
        public CogJobManager JobManager { get; set; }
        private CogJob mJob;
        private CogJobIndependent mIndependentJob;
        public event EventHandler JobManagerLoaded;
        public event EventHandler<JobLoadEventArgs> JobLoaded;
        public event EventHandler JobStopped;

        // Events
        public event EventHandler<TestStringEventArgs> TestResultsAvaliable;

        public class TestStringEventArgs : EventArgs
        {
            public List<BlobResult> blobs;
            public string testStatus;
            public ICogRecord LastRunImage { get; set; }
            public ICogRecord LastRunImage02 { get; set; }
        }

        public class JobLoadEventArgs : EventArgs
        {
            public string acqFifoState;
            public string acqFifoName;
        }

        public string VppPath { get; }

        //public List<CogJob> jobs = new List<CogJob>();q

        public QuickbuildManager(string aVppPath)
        {
            VppPath = aVppPath;
        }

        protected virtual void Dispose(bool disposing)
        {
            if (!disposed)
            {
                if (disposing)
                {
                    //dispose managed resources

                    // Disconnect framegrabbers
                    if (JobManager != null)
                    {
                        try
                        {
                            for (int i = 0; i < JobManager.JobCount; i++)
                            {
                                CogJob jobBreakout = JobManager.Job(i);

                                if (JobManager.Job(i).AcqFifo.FrameGrabber != null)
                                {
                                    JobManager.Job(i).AcqFifo.FrameGrabber.Disconnect(true);
                                }
                            }

                        }
                        catch { }
                        // Register handler for UserResultAvailable event
                        JobManager.UserResultAvailable -= new CogJobManager.CogUserResultAvailableEventHandler(JobManager_UserResultAvailable);
                        JobManager.Stopped -= new CogJobManager.CogJobManagerStoppedEventHandler(JobManager_Stopped);
                        JobManager.Shutdown();
                    }
                }
            }
            //dispose unmanaged resources
            disposed = true;
        }

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        protected virtual void OnJobLoadedCompleted(JobLoadEventArgs e)
        {
            JobLoaded?.Invoke(this, e);
        }

        protected virtual void OnJobManagerLoadedCompleted(EventArgs e)
        {
            JobManagerLoaded?.Invoke(this, e);
        }

        protected virtual void OnJobStopped(EventArgs e)
        {
            JobStopped?.Invoke(this, e);
        }

        public void LoadJobManager()
        {
            //Thread thread = new Thread(LoadJobManagerTasks);
            //thread.Start();
            LoadJobManagerTasks();
        }

        private void LoadJobManagerTasks()
        {
            JobManager = CogSerializer.LoadObjectFromFile(VppPath) as CogJobManager;
            //Cogser
            OnJobManagerLoadedCompleted(new EventArgs());
        }

        public void LoadJob(int jobIndex)
        {
            mJob = JobManager.Job(jobIndex);
            mIndependentJob = mJob.OwnedIndependent;

            // Flush Queues
            JobManager.UserQueueFlush();
            JobManager.FailureQueueFlush();
            mJob.ImageQueueFlush();
            mIndependentJob.RealTimeQueueFlush();


            // get acqFif
            JobLoadEventArgs messageArgs = new JobLoadEventArgs
            {
                acqFifoState = mJob.AcqFifoState.ToString(),
                acqFifoName = mJob.AcqFifo.ToString()
            };

            // Register handler for UserResultAvailable event
            JobManager.UserResultAvailable += new CogJobManager.CogUserResultAvailableEventHandler(JobManager_UserResultAvailable);
            JobManager.Stopped += new CogJobManager.CogJobManagerStoppedEventHandler(JobManager_Stopped);

            OnJobLoadedCompleted(messageArgs);
        }

        public void RunJob()
        {
            mJob = JobManager.Job(0);
            
            mJob.Run();
        }

        private void JobManager_UserResultAvailable(object sender, CogJobManagerActionEventArgs e)
        {
            try
            {
                Cognex.VisionPro.ICogRecord topRecord = JobManager.UserResult();
                Cognex.VisionPro.ICogRecord tmpRecord = null;
                Cognex.VisionPro.ICogRecord tmpRecord02 = null;
                List<string> recordDescriptionList = new List<string>();
                List<BlobResult> blobResultsList = new List<BlobResult>();
                if (topRecord != null)
                {
                    Cognex.VisionPro.ICogRecords recordList = topRecord.SubRecords;
                    //List<VisionProPostedItem> xmlPostedItems = null;
                    string testStatusTemp = "g";

                    // check job status
                    if (mJob.RunStatus.Result != CogToolResultConstants.Accept)
                        testStatusTemp = "ng";

                    // Iterate through record
                    foreach (ICogRecord record in recordList)
                    {
                        if (record.Annotation == "CogBlobResultsCollection")
                        {
                            CogBlobResultCollection BlobCollection = (CogBlobResultCollection)record.Content;

                            foreach(CogBlobResult blobResult in BlobCollection)
                            {
                                blobResultsList.Add(new BlobResult { CenterX = blobResult.CenterOfMassX, CenterY = blobResult.CenterOfMassY }); 
                            }

                        }
                        recordDescriptionList.Add(record.Annotation);
                    }


                    // Image for Display
                    tmpRecord = topRecord.SubRecords["ShowLastRunRecordForUserQueue"];
                    tmpRecord = tmpRecord.SubRecords["LastRun"];
                    tmpRecord = tmpRecord.SubRecords["Image Source.OutputImage"];

                    FireTestResultsMessageEvent(blobResultsList, testStatusTemp, tmpRecord, tmpRecord02);
                }
            }
            catch { }
        }

        private void TestResultsMessageEvent(TestStringEventArgs e)
        {
            TestResultsAvaliable?.Invoke(this, e);
        }

        private void FireTestResultsMessageEvent(List<BlobResult> blobs, string aTestStatus, ICogRecord aLastRunImage, ICogRecord aLastRunImage02)
        {
            TestStringEventArgs testMessageArgs = new TestStringEventArgs
            {
                blobs = blobs,
                testStatus = aTestStatus,
                LastRunImage = aLastRunImage,
                LastRunImage02 = aLastRunImage02
            };
            TestResultsMessageEvent(testMessageArgs);
        }

        private void JobManager_Stopped(object sender, CogJobManagerActionEventArgs e)
        {
            OnJobStopped(new EventArgs());
        }

        private void WriteToLogFile(string path, string data)
        {
            try
            {
                using (StreamWriter dataWriter = File.AppendText(path))
                {
                    //string writestring = "";

                    dataWriter.WriteLine(data);
                    dataWriter.Flush();
                    dataWriter.Close();
                }
            }
            catch { }
        }

        public string GetFrameGrabberStatus()
        {
            Cognex.VisionPro.CogFrameGrabberStatusConstants Cached = CogFrameGrabberStatusConstants.Active;

            return Cached.ToString();
        }
    }
}
