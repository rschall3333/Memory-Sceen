﻿namespace CMM_Study
{
    struct VisionProPostedItem
    {
        public string description;
        public bool triggerImage;
        public string path;
        public string expectedValue;
        public string minValue;
        public string maxValue;
        public string value;
        public string eval;


        public VisionProPostedItem(string mDescription, bool mTriggerImage, string mPath,
                                    string mExpectedValue, string mMinValue, string mMaxValue,
                                    string mValue)
        {
            description = mDescription;
            triggerImage = mTriggerImage;
            path = mPath;
            expectedValue = mExpectedValue;
            minValue = mMinValue;
            maxValue = mMaxValue;
            value = mValue;
            eval = "ng";
        }
    }
}

