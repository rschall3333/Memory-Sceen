﻿
using System;

namespace CMM_Study
{
    partial class CMM_Study_Form
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(CMM_Study_Form));
            this.cogRecordDisplayMain = new Cognex.VisionPro.CogRecordDisplay();
            this.ProcessTimer = new System.Windows.Forms.Timer(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.cogRecordDisplayMain)).BeginInit();
            this.SuspendLayout();
            // 
            // cogRecordDisplayMain
            // 
            this.cogRecordDisplayMain.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.cogRecordDisplayMain.ColorMapLowerClipColor = System.Drawing.Color.Black;
            this.cogRecordDisplayMain.ColorMapLowerRoiLimit = 0D;
            this.cogRecordDisplayMain.ColorMapPredefined = Cognex.VisionPro.Display.CogDisplayColorMapPredefinedConstants.None;
            this.cogRecordDisplayMain.ColorMapUpperClipColor = System.Drawing.Color.Black;
            this.cogRecordDisplayMain.ColorMapUpperRoiLimit = 1D;
            this.cogRecordDisplayMain.DoubleTapZoomCycleLength = 2;
            this.cogRecordDisplayMain.DoubleTapZoomSensitivity = 2.5D;
            this.cogRecordDisplayMain.Location = new System.Drawing.Point(12, 12);
            this.cogRecordDisplayMain.MouseWheelMode = Cognex.VisionPro.Display.CogDisplayMouseWheelModeConstants.Zoom1;
            this.cogRecordDisplayMain.MouseWheelSensitivity = 1D;
            this.cogRecordDisplayMain.Name = "cogRecordDisplayMain";
            this.cogRecordDisplayMain.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("cogRecordDisplayMain.OcxState")));
            this.cogRecordDisplayMain.Size = new System.Drawing.Size(825, 392);
            this.cogRecordDisplayMain.TabIndex = 0;
            this.cogRecordDisplayMain.DoubleClick += new System.EventHandler(this.CogRecordDisplayMain_DoubleClick);
            // 
            // ProcessTimer
            // 
            this.ProcessTimer.Tick += new System.EventHandler(this.ProcessTimer_Tick);
            // 
            // CMM_Study_Form
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(849, 416);
            this.Controls.Add(this.cogRecordDisplayMain);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "CMM_Study_Form";
            this.Opacity = 0.75D;
            this.Text = "CMM Study";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.CMM_Study_Form_FormClosing);
            this.Load += new System.EventHandler(this.CMM_Study_Form_Load);
            ((System.ComponentModel.ISupportInitialize)(this.cogRecordDisplayMain)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private Cognex.VisionPro.CogRecordDisplay cogRecordDisplayMain;
        private System.Windows.Forms.Timer ProcessTimer;
    }
}

