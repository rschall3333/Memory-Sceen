﻿namespace CMM_Study
{
    public class Rootobject
    {
        public JsonTrigger[] Property1 { get; set; }
    }

    public class JsonTrigger
    {
        public int trigger { get; set; }
    }
}

