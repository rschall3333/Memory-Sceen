﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Text.Json;
using System.Text.Json.Serialization;

namespace CMM_Study
{
    public partial class CMM_Study_Form : Form
    {
        #region "System Variables"  
        QuickbuildManager qbManager = null;
        public QuickBuild_Form QuickBuild = null;
        string QuickBuildJobPath = "CameraPos.vpp";
        string jsonTriggerPath = $"{AppContext.BaseDirectory}trigger.json";
        string jsonOutputPath = $"{AppContext.BaseDirectory}blobCenterData.json";
        string title = "CMM Study";
        JsonTrigger jsonTrigger = new JsonTrigger();
        #endregion

        #region "Delegates"
        delegate void QBManager_ManagerLoaded_Callback(object sender, EventArgs e);
        delegate void QBManager_JobLoaded_Callback(object sender, QuickbuildManager.JobLoadEventArgs e);
        delegate void QbManager_UserResultsAvailableCallBack(object sender, QuickbuildManager.TestStringEventArgs e);
        #endregion

        public CMM_Study_Form()
        {
            InitializeComponent();
        }

        private void CMM_Study_Form_Load(object sender, EventArgs e)
        {   
            // Set properties for Cognex display
            this.Icon = new System.Drawing.Icon($@"{AppContext.BaseDirectory}\index.ico");
            this.cogRecordDisplayMain.Anchor = AnchorStyles.Top;
            this.cogRecordDisplayMain.Anchor = AnchorStyles.Left;
            this.cogRecordDisplayMain.Anchor = AnchorStyles.Bottom;
            this.cogRecordDisplayMain.Anchor = AnchorStyles.Right;
            this.cogRecordDisplayMain.VerticalScrollBar = false;
            this.cogRecordDisplayMain.HorizontalScrollBar = false;
            this.cogRecordDisplayMain.Size = new Size(this.Size.Width - 50, this.Size.Height - 70);
            this.Location = new Point(0, 0);

            // Load the Quickbuild manager
            qbManager = new QuickbuildManager($"{AppContext.BaseDirectory}{QuickBuildJobPath}");
            qbManager.JobManagerLoaded += new EventHandler(QBManager_ManagerLoaded);                              // event handler vpp load
            qbManager.JobLoaded += new EventHandler<QuickbuildManager.JobLoadEventArgs>(QBManager_JobLoaded);                              // event handler vpp load
            qbManager.TestResultsAvaliable += new EventHandler<QuickbuildManager.TestStringEventArgs>(QBManager_UserResultsAvailable);
            qbManager.LoadJobManager();                                                             // load job manager (vpp)

            qbManager.LoadJob(0);
        }
        private void QBManager_ManagerLoaded(object sender, EventArgs e)
        {
            switch (this.InvokeRequired)
            {
                case true:
                    this.BeginInvoke(new QBManager_ManagerLoaded_Callback(QBManager_ManagerLoaded), new object[] { sender, e });
                    break;
                default:
                    this.Text = $"{title} — Loaded";
                    qbManager.LoadJob(0);
                    break;
            }
        }
        private void QBManager_JobLoaded(object sender, QuickbuildManager.JobLoadEventArgs e)
        {
            switch (this.InvokeRequired)
            {
                case true:
                    this.BeginInvoke(new QBManager_JobLoaded_Callback(QBManager_JobLoaded), new object[] { sender, e });
                    break;
                default:
                    // Check AcqFifo State
                    if (e.acqFifoState != "Valid")
                    {
                        
                    }

                    // Start process timer
                    ProcessTimer.Enabled = true;
                    break;
            }
        }
        void QBManager_UserResultsAvailable(object sender, QuickbuildManager.TestStringEventArgs e)
        {
            switch (this.InvokeRequired)
            {
                case true:
                    this.BeginInvoke(new QbManager_UserResultsAvailableCallBack(QBManager_UserResultsAvailable), new object[] { sender, e });
                    break;
                default:
                    JsonSerializerOptions options = new JsonSerializerOptions { WriteIndented = true };

                    cogRecordDisplayMain.Record = e.LastRunImage;
                    cogRecordDisplayMain.Fit();

                    // Write JSON
                    var output = JsonSerializer.Serialize(e.blobs, options ?? new JsonSerializerOptions() { WriteIndented = true });
                    File.WriteAllText(jsonOutputPath, output);
                    break;
            }
        }

        private void CogRecordDisplayMain_DoubleClick(object sender, EventArgs e)
        {
            QuickBuild = new QuickBuild_Form(this, qbManager.JobManager);
            QuickBuild.Show();
        }

        private void CMM_Study_Form_FormClosing(object sender, FormClosingEventArgs e)
        {

            // Stop process timer
            try
            {
                ProcessTimer.Stop();
                ProcessTimer.Enabled = false;
                ProcessTimer.Dispose();
            }
            catch { }

            // Remove Handlers
            try
            {
                qbManager.JobManagerLoaded -= new EventHandler(QBManager_ManagerLoaded);
                qbManager.JobLoaded -= new EventHandler<QuickbuildManager.JobLoadEventArgs>(QBManager_JobLoaded);
                qbManager.TestResultsAvaliable -= new EventHandler<QuickbuildManager.TestStringEventArgs>(QBManager_UserResultsAvailable);
            } 
            catch { }

            // Dispose qb manager
            try { qbManager.Dispose(); }        
            catch { }
        }

        private void ReadJsonTrigger(string path)
        {
           FileStream fileStream = File.OpenRead(path);
            
        }

        private void ProcessTimer_Tick(object sender, EventArgs e)
        {
            if (File.Exists(jsonTriggerPath))
            {
                // Trigger camera                               
                qbManager.RunJob();
                // Delete file
                File.Delete(jsonTriggerPath);
            }
        }
    }
}
