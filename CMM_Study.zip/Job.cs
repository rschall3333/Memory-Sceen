﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CMM_Study
{
    class Job
    {
        public string JobName { get; }
        public int JobNumber { get; }
        public string RecordedImagePath { get; set; }
        public bool RecordedImage { get; set; }
        public string RecordedNgImagePath { get; set; }
        public bool RecordedNgImage { get; set; }
        public string ImageRecordNameDisplay { get; }           // used for CogRecordsDisplay tool
        public string ImageRecordNameSaveImage { get; }
        public string ImageRecordSaveImageType { get; }

        public List<VisionProPostedItem> PostedItems { get; set; }
        public VisionProFramegrabber FrameGrabber { get; }

        public Job(string mJobName, int mJobNumber, string mRecordedImagePath,
                    bool mRecordedImage, string mRecordedNgImagePath,
                    bool mRecoredNgImage, string mImageRecordNameDisplay,
                    string mImageRecordNameSaveImage, string mImageRecordSaveImageType,
                    List<VisionProPostedItem> mPostedItems, VisionProFramegrabber mFrameGrabber)
        {
            JobName = mJobName;
            JobNumber = mJobNumber;
            RecordedImagePath = mRecordedImagePath;
            RecordedImage = mRecordedImage;
            RecordedNgImagePath = mRecordedNgImagePath;
            RecordedNgImage = mRecoredNgImage;
            ImageRecordNameDisplay = mImageRecordNameDisplay;
            ImageRecordNameSaveImage = mImageRecordNameSaveImage;
            ImageRecordSaveImageType = mImageRecordSaveImageType;
            PostedItems = mPostedItems;
            FrameGrabber = mFrameGrabber;
        }
    }
}
