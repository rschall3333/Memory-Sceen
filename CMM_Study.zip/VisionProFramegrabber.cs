﻿using Cognex.VisionPro;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CMM_Study
{
    class VisionProFramegrabber
    {
        public bool enable;
        public string name;
        public string serialNumber;
        //public string uniqueID;
        public string videoFormat;
        public CogAcqFifoPixelFormatConstants fifoType;
        public int index;
        public double exposure;
        public double brightness;
        public double contrast;
        public int timeout;
        public string roiMode;
        public int imageX;
        public int imageY;
        public int imageWidth;
        public int imageHeight;
        public int retriggerMax;

        public VisionProFramegrabber(bool mEnable, string mName, string mSerialNumber, string mVideoFormat, CogAcqFifoPixelFormatConstants mFifoType,
                                    int mIndex, double mExposure, double mBrightness, double mContrast, int mTimeout,
                                    string mRoiMode, int mImageX, int mImageY, int mImageWidth, int mImageHeight, int mRetriggerMax)
        {
            enable = mEnable;
            name = mName;
            serialNumber = mSerialNumber;
            //uniqueID = mUniqueID;
            videoFormat = mVideoFormat;
            fifoType = mFifoType;
            index = mIndex;
            exposure = mExposure;
            brightness = mBrightness;
            contrast = mContrast;
            timeout = mTimeout;
            roiMode = mRoiMode;
            imageX = mImageX;
            imageY = mImageY;
            imageWidth = mImageWidth;
            imageHeight = mImageHeight;
            retriggerMax = mRetriggerMax;
        }
    }
}
