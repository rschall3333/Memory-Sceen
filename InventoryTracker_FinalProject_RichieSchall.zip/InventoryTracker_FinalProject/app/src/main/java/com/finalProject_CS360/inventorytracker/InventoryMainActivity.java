package com.finalProject_CS360.inventorytracker;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;

public class InventoryMainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inventory_main);
    }

    public void InventoryScreen(View view){
        // Start InventoryMainActivity
        Intent intent = new Intent(this, InventoryListActivity.class);

        startActivity(intent);
    }

    public void AddInventory(View view){
        // Start InventoryMainActivity
        Intent intent = new Intent(this, AddInventoryActivity.class);

        startActivity(intent);
    }

    public void FindInventory(View view){
        // Start InventoryMainActivity
        Intent intent = new Intent(this, ItemLookupActivity.class);

        startActivity(intent);
    }
}