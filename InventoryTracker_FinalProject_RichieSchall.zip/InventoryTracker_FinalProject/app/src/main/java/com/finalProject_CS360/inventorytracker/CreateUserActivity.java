package com.finalProject_CS360.inventorytracker;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.Toast;

public class CreateUserActivity extends AppCompatActivity {
    private EditText mUserName;
    private EditText mFirstName;
    private EditText mLastName;
    private EditText mPassword;
    private InventoryDatabase mStudyDb;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Singleton
        mStudyDb = InventoryDatabase.getInstance(getApplicationContext());

        setContentView(R.layout.activity_create_user);

        mUserName = findViewById(R.id.editTextTextItemName);
        mFirstName = findViewById(R.id.editTextTextItemDescription);
        mLastName = findViewById(R.id.editTextTextQuantity);
        mPassword = findViewById(R.id.editTextTextPassword);

        // Clear user name upon focus
        mUserName.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View view, boolean hasFocus) {
                if (hasFocus) {  mUserName.setText(""); }
            }
        });

        // Clear first name upon focus
        mFirstName.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View view, boolean hasFocus) {
                if (hasFocus) {  mFirstName.setText(""); }
            }
        });

        // Clear last name upon focus
        mLastName.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View view, boolean hasFocus) {
                if (hasFocus) {  mLastName.setText(""); }
            }
        });

        // Clear password upon focus
        mPassword.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View view, boolean hasFocus) {
                if (hasFocus) { mPassword.setText(""); }
            }
        });
    }

    public void SaveUser(View view){
        User user = new User();
        User userRetrieve;

        // Minimize keyboard
        InputMethodManager mgr = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        mgr.hideSoftInputFromWindow(mUserName.getWindowToken(), 0);

        user.setUserName(mUserName.getText().toString());
        user.setFirstName(mFirstName.getText().toString());
        user.setLastName(mLastName.getText().toString());
        user.setPassword(mPassword.getText().toString());

        // Check to see if user exists in database
        userRetrieve = mStudyDb.getUser(mUserName.getText().toString());
        if (userRetrieve != null){
            String message = getResources().getString(R.string.user_create_exists);
            Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
        }
        else {
            // Add user to database
            mStudyDb.addUser(user);

            // Go back to Login screen
            Intent intent = new Intent(this, MainActivity.class);

            startActivity(intent);
        }
    }

    public void Cancel(View view){
        // Go back to Login screen
        Intent intent = new Intent(this, MainActivity.class);

        startActivity(intent);
    }

    public void Click(View view){
        // Minimize keyboard
        InputMethodManager mgr = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        mgr.hideSoftInputFromWindow(mUserName.getWindowToken(), 0);
    }
}