package com.finalProject_CS360.inventorytracker;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Build;

import java.util.ArrayList;
import java.util.List;

public class InventoryDatabase extends SQLiteOpenHelper {
    private static final int VERSION = 1;
    private static final String DATABASE_NAME = "inventory.db";

    private static InventoryDatabase mInventoryDb;

    public enum UserSortOrder { ALPHABETIC, UPDATE_DESC, UPDATE_ASC};
    public enum InventoryItemSortOrder { ALPHABETIC, UPDATE_DESC, UPDATE_ASC};

    public static InventoryDatabase getInstance(Context context) {
        if (mInventoryDb == null) {
            mInventoryDb = new InventoryDatabase(context);
        }
        return mInventoryDb;
    }

    private InventoryDatabase(Context context) {

        super(context, DATABASE_NAME, null, VERSION);
    }

    // Table declaration for the users table
    private static final class UserTable {
        private static final String TABLE = "users";
        private static final String COL_USERNAME = "userName";
        private static final String COL_FIRST = "firstName";
        private static final String COL_LAST = "lastName";
        private static final String COL_PASSWORD = "password";
    }

    // Table declaration for the inventory table
    private static final class InventoryTable {
        private static final String TABLE = "inventory";
        private static final String COL_ID = "_id";
        private static final String COL_TEXT = "item";
        private static final String COL_DESCRIPTION = "description";
        private static final String COL_QTY = "quantity";
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        // Create users table
        sqLiteDatabase.execSQL("create table " + UserTable.TABLE + " (" +
                UserTable.COL_USERNAME + " primary key , " +
                UserTable.COL_FIRST + ", " +
                UserTable.COL_LAST + ", " +
                UserTable.COL_PASSWORD + " )");

        // Create inventory table
        sqLiteDatabase.execSQL("create table " + InventoryTable.TABLE + " (" +
                InventoryTable.COL_ID + " integer primary key autoincrement, " +
                InventoryTable.COL_TEXT + ", " +
                InventoryTable.COL_DESCRIPTION + ", " +
                InventoryTable.COL_QTY + ")");

        // Add some users
        String[] userName = {"Administrator", "Maintenance"};
        String[] userFirstName = {"", ""};
        String[] userLastName = {"", ""};
        String[] password = {"administrator", "maintenance"};
        int index = 0;

        for (String usr: userName) {
            User user = new User(usr, userFirstName[index], userLastName[index], password[index]);
            ContentValues values = new ContentValues();
            values.put(UserTable.COL_USERNAME, user.getUserName());
            values.put(UserTable.COL_FIRST, user.getFirstName());
            values.put(UserTable.COL_LAST, user.getLastName());
            values.put(UserTable.COL_PASSWORD, user.getPassword());
            sqLiteDatabase.insert(UserTable.TABLE, null, values);
            index++;
        }
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {
        sqLiteDatabase.execSQL("drop table if exists " + UserTable.TABLE);
        sqLiteDatabase.execSQL("drop table if exists " + InventoryTable.TABLE);
        onCreate(sqLiteDatabase);
    }

    @Override
    public void onOpen(SQLiteDatabase db) {
        super.onOpen(db);
        if (!db.isReadOnly()) {
            // Enable foreign key constraints
            if (Build.VERSION.SDK_INT < Build.VERSION_CODES.JELLY_BEAN) {
                db.execSQL("pragma foreign_keys = on;");
            } else {
                db.setForeignKeyConstraintsEnabled(true);
            }
        }
    }

    public User getUser(String userName){
        User user = null;

        SQLiteDatabase db = getReadableDatabase();
        String sql = "select * from " + UserTable.TABLE +
                " where " + UserTable.COL_USERNAME + " = ?";
        Cursor cursor = db.rawQuery(sql, new String[] { userName });

        if (cursor.moveToFirst() && cursor.getCount() != -1){
            do {
                user = new User();
                user.setUserName(cursor.getString(0));
                user.setFirstName(cursor.getString(1));
                user.setLastName(cursor.getString(2));
                user.setPassword(cursor.getString(3));
            } while (cursor.moveToNext());
        }
        cursor.close();

        return user;
    }

    public boolean addUser(User user) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(UserTable.COL_USERNAME, user.getUserName());
        values.put(UserTable.COL_FIRST, user.getFirstName());
        values.put(UserTable.COL_LAST, user.getLastName());
        values.put(UserTable.COL_PASSWORD, user.getPassword());
        long id = db.insert(UserTable.TABLE, null, values);
        return id != -1;
    }

    public void updateUser(User user){
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(UserTable.COL_FIRST, user.getFirstName());
        values.put(UserTable.COL_LAST, user.getLastName());
        values.put(UserTable.COL_PASSWORD, user.getPassword());
        db.update(UserTable.TABLE, values,
                UserTable.COL_FIRST + " = ? AND " + UserTable.COL_LAST + " = ?",
                new String[] { user.getFirstName(), user.getLastName() });
    }

    public void deleteUser(User user){
        SQLiteDatabase db = getWritableDatabase();
        db.delete(UserTable.TABLE,
                UserTable.COL_FIRST + " = ? AND " + UserTable.COL_LAST + " = ?",
                new String[] { user.getFirstName(), user.getLastName() });
    }

    public boolean addInventoryItem(InventoryItem item){
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(InventoryTable.COL_TEXT, item.getItemName());
        values.put(InventoryTable.COL_DESCRIPTION, item.getDescription());
        values.put(InventoryTable.COL_QTY, item.getQuantity());
        long id = db.insert(InventoryTable.TABLE, null, values);
        return id != -1;
    }

    public void updateInventoryItem(InventoryItem item){
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(InventoryTable.COL_TEXT, item.getItemName());
        values.put(InventoryTable.COL_DESCRIPTION, item.getDescription());
        values.put(InventoryTable.COL_QTY, item.getQuantity());
        db.update(InventoryTable.TABLE, values,
                InventoryTable.COL_ID + " = " + item.getId(), null);
    }

    public void deleteInventoryItem(InventoryItem item){
        SQLiteDatabase db = getWritableDatabase();
        db.delete(InventoryTable.TABLE,
                InventoryTable.COL_ID + " = " + item.getId(), null);
    }

    public List<InventoryItem> getInventoryItems() {
        List<InventoryItem> inventoryItems = new ArrayList<>();

        SQLiteDatabase db = getReadableDatabase();
        String sql = "select * from " + InventoryTable.TABLE;
        Cursor cursor = db.rawQuery(sql, new String[] {});
        if (cursor.moveToFirst()) {
            do {
                InventoryItem item = new InventoryItem();
                item.setId(cursor.getInt(0));
                item.setItemName(cursor.getString(1));
                item.setDescription(cursor.getString(2));
                item.setQuantity(cursor.getString(3));
                inventoryItems.add(item);
            } while (cursor.moveToNext());
        }
        cursor.close();

        return inventoryItems;
    }

    public InventoryItem getInventoryItem(String name){
        InventoryItem item = null;

        SQLiteDatabase db = getReadableDatabase();
        String sql = "select * from " + InventoryTable.TABLE +
                " where " + InventoryTable.COL_TEXT + " = ?";
        Cursor cursor = db.rawQuery(sql, new String[] { name });

        if (cursor.moveToFirst()) {
            do {
                item = new InventoryItem();
                item.setId(cursor.getInt(0));
                item.setItemName(cursor.getString(1));
                item.setDescription(cursor.getString(2));
                item.setQuantity(cursor.getString(3));
            } while (cursor.moveToNext());
        }
        cursor.close();

        return item;
    }
}
