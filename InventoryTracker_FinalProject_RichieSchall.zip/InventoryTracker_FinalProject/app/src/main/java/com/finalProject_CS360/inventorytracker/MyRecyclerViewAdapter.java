package com.finalProject_CS360.inventorytracker;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class MyRecyclerViewAdapter extends RecyclerView.Adapter<MyRecyclerViewAdapter.ViewHolder> {

    private List<String> mDataID;
    private List<String> mDataDescription;
    private List<String> mDataQuantity;
    private LayoutInflater mInflater;
    private ItemClickListener mClickListener;


    // data is passed into the constructor
    MyRecyclerViewAdapter(Context context, List<String> dataID, List<String> dataDescription, List<String> dataQuantity) {
        this.mInflater = LayoutInflater.from(context);
        this.mDataID = dataID;
        this.mDataDescription = dataDescription;
        this.mDataQuantity = dataQuantity;
    }

    // inflates the row layout from xml when needed
    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = mInflater.inflate(R.layout.recyclerview_row, parent, false);
        return new ViewHolder(view);
    }

    // binds the data to the TextView in each row
    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {
        String itemID = mDataID.get(position);
        String itemDescription = mDataDescription.get(position);
        String itemQuantity = mDataQuantity.get(position);

        holder.myTextView00.setText(itemID);
        holder.myTextView01.setText(itemDescription);
        holder.myTextView02.setText(itemQuantity);
    }

    // total number of rows
    @Override
    public int getItemCount() {
        return mDataID.size();
    }

    // stores and recycles views as they are scrolled off screen
    public class ViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
        TextView myTextView00;
        TextView myTextView01;
        TextView myTextView02;

        ViewHolder(View itemView) {
            super(itemView);
            myTextView00 = itemView.findViewById(R.id.tvInventoryItemID);
            myTextView01 = itemView.findViewById(R.id.tvInventoryItemDescription);
            myTextView02 = itemView.findViewById(R.id.tvInventoryItemQuantity);
            itemView.setOnClickListener(this);
        }

        @Override
        public void onClick(View view) {
            if (mClickListener != null) mClickListener.onItemClick(view, getAdapterPosition());
        }

    }

    // convenience method for getting data at click position
    String getItem(int id) {
        return mDataID.get(id);
    }
    // allows clicks events to be caught
    void setClickListener(ItemClickListener itemClickListener) {
        this.mClickListener = itemClickListener;
    }

    // parent activity will implement this method to respond to click events
    public interface ItemClickListener {
        void onItemClick(View view, int position);
    }
}