package com.finalProject_CS360.inventorytracker;

public class InventoryItem {

    private int mId;
    private String mItemName;
    private String mDescription;
    private String mQuantity;

    public InventoryItem() {}

    // Constructor
    public InventoryItem(String name, String description, String quantity) {
        mItemName = name;
        mDescription = description;
        mQuantity = quantity;
    }

    public int getId() {
        return mId;
    }

    public void setId(int id) {
        this.mId = id;
    }

    public String getItemName() {
        return mItemName;
    }

    public void setItemName(String mItemName) {
        this.mItemName = mItemName;
    }

    public String getDescription() {
        return mDescription;
    }

    public void setDescription(String description) {
        this.mDescription = description;
    }

    public String getQuantity() {
        return mQuantity;
    }

    public void setQuantity(String quantity) {
        this.mQuantity = quantity;
    }
}
