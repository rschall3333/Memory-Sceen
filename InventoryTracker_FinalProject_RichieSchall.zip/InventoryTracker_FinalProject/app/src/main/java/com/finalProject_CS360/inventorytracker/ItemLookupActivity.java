package com.finalProject_CS360.inventorytracker;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class ItemLookupActivity extends AppCompatActivity {
    private EditText mItemName;
    private TextView mItemNumber;
    private EditText mItemDescription;
    private EditText mItemQuantity;
    private InventoryDatabase mStudyDb;
    InventoryItem itemRetrieve;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Singleton
        mStudyDb = InventoryDatabase.getInstance(getApplicationContext());

        setContentView(R.layout.activity_item_lookup);

        mItemName = findViewById(R.id.editTextTextItemName);
        mItemNumber = findViewById(R.id.textViewItemID);
        mItemDescription = findViewById(R.id.editTextTextItemDescription);
        mItemQuantity = findViewById(R.id.editTextTextQuantity);

        // Clear item name upon focus
        mItemName.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View view, boolean hasFocus) {
                if (hasFocus) {  mItemName.setText(""); }
            }
        });

        // Clear item description upon focus
        mItemDescription.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View view, boolean hasFocus) {
                if (hasFocus) {  mItemDescription.setText(""); }
            }
        });

        // Clear item quantity upon focus
        mItemQuantity.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View view, boolean hasFocus) {
                if (hasFocus) {  mItemQuantity.setText(""); }
            }
        });
    }

    public void LookupItem(View view) {
        // Minimize keyboard
        InputMethodManager mgr = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        mgr.hideSoftInputFromWindow(mItemName.getWindowToken(), 0);

        // Check to see if user exists in database
        itemRetrieve = mStudyDb.getInventoryItem(mItemName.getText().toString());
        if (itemRetrieve != null) {
            mItemNumber.setText("ID# " + String.valueOf(itemRetrieve.getId()));
            mItemDescription.setText(itemRetrieve.getDescription());
            mItemQuantity.setText(itemRetrieve.getQuantity());
        } else {
            String message = getResources().getString(R.string.item_not_found);
            Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
        }
    }

    public void UpdateInventoryItem(View view){
        // Minimize keyboard
        InputMethodManager mgr = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        mgr.hideSoftInputFromWindow(mItemName.getWindowToken(), 0);

        itemRetrieve.setItemName(mItemName.getText().toString());
        itemRetrieve.setDescription(mItemDescription.getText().toString());
        itemRetrieve.setQuantity(mItemQuantity.getText().toString());

        mStudyDb.updateInventoryItem(itemRetrieve);

        // Display user message that item has been updated
        String message = getResources().getString(R.string.item_updated);
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();

        // Go to InventoryMainActivity
        Intent intent = new Intent(this, InventoryMainActivity.class);

        startActivity(intent);
    }

    public void DeleteInventoryItem(View view){
        // Minimize keyboard
        InputMethodManager mgr = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        mgr.hideSoftInputFromWindow(mItemName.getWindowToken(), 0);

        mStudyDb.deleteInventoryItem(itemRetrieve);

        // Display user message that item has been deleted
        String message = getResources().getString(R.string.item_deleted);
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();

        // Go to InventoryMainActivity
        Intent intent = new Intent(this, InventoryMainActivity.class);

        startActivity(intent);
    }

    public void Cancel(View view){
        // Go to InventoryMainActivity
        Intent intent = new Intent(this, InventoryMainActivity.class);

        startActivity(intent);
    }

    public void Click(View view){
        // Minimize keyboard
        InputMethodManager mgr = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        mgr.hideSoftInputFromWindow(mItemName.getWindowToken(), 0);
    }
}