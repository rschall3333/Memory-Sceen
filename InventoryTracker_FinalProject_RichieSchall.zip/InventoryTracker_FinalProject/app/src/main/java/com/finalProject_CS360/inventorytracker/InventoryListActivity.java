package com.finalProject_CS360.inventorytracker;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class InventoryListActivity extends AppCompatActivity implements MyRecyclerViewAdapter.ItemClickListener {
    MyRecyclerViewAdapter adapter;
    private InventoryDatabase mStudyDb;
    private List<InventoryItem> mInventoryItems;
    private ArrayList<Integer> mInventoryItemsID = new ArrayList<>();     // individual list for item IDs
    private ArrayList<String> mInventoryItemsName = new ArrayList<>();     // individual list for item names
    private ArrayList<String> mInventoryItemsDescription = new ArrayList<>();    // individual list for item descriptions
    ArrayList<String> mInventoryItemsQuantity = new ArrayList<>();    // individual list for item quantities

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Add a header row
        mInventoryItemsName.add("Name");
        mInventoryItemsDescription.add("Description");
        mInventoryItemsQuantity.add("Qty");


        // Singleton
        mStudyDb = InventoryDatabase.getInstance(getApplicationContext());

        setContentView(R.layout.activity_inventory_list);

        // Get all inventory items
        mInventoryItems = mStudyDb.getInventoryItems();

        // data to populate the item lists
        for (InventoryItem item: mInventoryItems) {
            mInventoryItemsID.add(item.getId());
            mInventoryItemsName.add(item.getItemName());
            mInventoryItemsDescription.add(item.getDescription());
            mInventoryItemsQuantity.add(item.getQuantity());
        }

        // set up the RecyclerView
        RecyclerView recyclerView = findViewById(R.id.rvInventoryItems);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        adapter = new MyRecyclerViewAdapter(this, mInventoryItemsName, mInventoryItemsDescription, mInventoryItemsQuantity);
        adapter.setClickListener(this);
        recyclerView.setAdapter(adapter);

        DividerItemDecoration dividerItemDecoration = new DividerItemDecoration(recyclerView.getContext(),
                DividerItemDecoration.VERTICAL);
        recyclerView.addItemDecoration(dividerItemDecoration);
    }

    @Override
    public void onItemClick(View view, int position) {
        Toast.makeText(this, "You clicked " + adapter.getItem(position) + " on row number " + position, Toast.LENGTH_SHORT).show();
    }



    public void Back(View view, int position) {
        // Go to InventoryMainActivity
        Intent intent = new Intent(this, InventoryMainActivity.class);

        startActivity(intent);
    }
}