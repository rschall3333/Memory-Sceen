package com.finalProject_CS360.inventorytracker;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.util.List;

public class MainActivity extends AppCompatActivity {
    private Button mButtonCreateUser;
    private EditText mUserName;
    private EditText mPassword;
    private InventoryDatabase mStudyDb;
    private static final int MY_PERMISSIONS_REQUEST_SEND_SMS = 1;
    public static final String TAG = MainActivity.class.getSimpleName();



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        List<InventoryItem> items;
        InventoryItem item = new InventoryItem("test", "test", "1");
        setContentView(R.layout.activity_main);

        // Check for permission to use SMS messaging
        checkForSmsPermission();

        // Singleton
        mStudyDb = InventoryDatabase.getInstance(getApplicationContext());

        // Find Controls and associate with local variable
        mButtonCreateUser = findViewById(R.id.createButton);
        mUserName = findViewById(R.id.editTextTextItemName);
        mPassword = findViewById(R.id.editTextTextPassword);

        // Clear user name upon focus
        mUserName.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View view, boolean hasFocus) {
                if (hasFocus) {  mUserName.setText(""); }
            }
        });

        // Clear password upon focus
        mPassword.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View view, boolean hasFocus) {
                if (hasFocus) { mPassword.setText(""); }
            }
        });
    }



    public void CreateUser(View view) {
        // Start CreateUserActivity
        Intent intent = new Intent(this, CreateUserActivity.class);

        startActivity(intent);
    }
    public void LoginUser(View view){
        String userName = mUserName.getText().toString();
        String password = mPassword.getText().toString();

        // Minimize keyboard
        InputMethodManager mgr = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        mgr.hideSoftInputFromWindow(mUserName.getWindowToken(), 0);

        // Verify UserName is not default or empty
        if (userName.equals("Username") || userName.equals("")) {
            String message = getResources().getString(R.string.invalid_username);
            Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
        }
        else {
            User user = mStudyDb.getUser(userName);

            // Check user against database
            if (user != null){
                // Check password
                if (password.equals("Password") || password.equals("")) {
                    String message = getResources().getString(R.string.invalid_password);
                    Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
                }
                else {
                    // Check password against database
                    if(user.getPassword().equals(password)) {
                        String message = getResources().getString(R.string.user_welcome);
                        Toast.makeText(this, message + " " + user.getFirstName() +
                                " " + user.getLastName() + "!", Toast.LENGTH_SHORT).show();

                        // Start InventoryMainActivity
                        Intent intent = new Intent(this, InventoryMainActivity.class);

                        startActivity(intent);
                    }
                    else {
                        String message = getResources().getString(R.string.wrong_password);
                        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
                    }

                }
            }
            else {
                String message = getResources().getString(R.string.username_not_found);
                Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
            }
        }
    }

    public void Click(View view){
        // Minimize keyboard
        InputMethodManager mgr = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        mgr.hideSoftInputFromWindow(mUserName.getWindowToken(), 0);
    }

    private void checkForSmsPermission() {
        if (ActivityCompat.checkSelfPermission(this,
                Manifest.permission.SEND_SMS) !=
                PackageManager.PERMISSION_GRANTED) {
            Log.d(TAG, getString(R.string.permission_not_granted));
            // Permission not yet granted. Use requestPermissions().
            // MY_PERMISSIONS_REQUEST_SEND_SMS is an
            // app-defined int constant. The callback method gets the
            // result of the request.
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.SEND_SMS},
                    MY_PERMISSIONS_REQUEST_SEND_SMS);
        } else {
            // Permission already granted. Enable the SMS button.

        }
    }
}

