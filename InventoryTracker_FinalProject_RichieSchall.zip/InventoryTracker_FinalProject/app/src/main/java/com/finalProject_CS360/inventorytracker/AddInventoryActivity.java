package com.finalProject_CS360.inventorytracker;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.Toast;

public class AddInventoryActivity extends AppCompatActivity {
    private EditText mItemName;
    private EditText mItemDescription;
    private EditText mItemQuantity;
    private InventoryDatabase mStudyDb;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Singleton
        mStudyDb = InventoryDatabase.getInstance(getApplicationContext());

        setContentView(R.layout.activity_add_inventory);

        mItemName = findViewById(R.id.editTextTextItemName);
        mItemDescription = findViewById(R.id.editTextTextItemDescription);
        mItemQuantity = findViewById(R.id.editTextTextQuantity);

        // Clear item name upon focus
        mItemName.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View view, boolean hasFocus) {
                if (hasFocus) {  mItemName.setText(""); }
            }
        });

        // Clear item description upon focus
        mItemDescription.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View view, boolean hasFocus) {
                if (hasFocus) {  mItemDescription.setText(""); }
            }
        });

        // Clear item quantity upon focus
        mItemQuantity.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View view, boolean hasFocus) {
                if (hasFocus) {  mItemQuantity.setText(""); }
            }
        });
    }

    public void SaveInventoryItem(View view){
        InventoryItem item = new InventoryItem();
        InventoryItem itemRetrieve;

        // Minimize keyboard
        InputMethodManager mgr = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        mgr.hideSoftInputFromWindow(mItemName.getWindowToken(), 0);

        item.setItemName(mItemName.getText().toString());
        item.setDescription(mItemDescription.getText().toString());
        item.setQuantity(mItemQuantity.getText().toString());

        // Check to see if user exists in database
        itemRetrieve = mStudyDb.getInventoryItem(mItemName.getText().toString());
        if (itemRetrieve != null){
            String message = getResources().getString(R.string.item_create_exists);
            Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
        }
        else {
            // Add user to database
            mStudyDb.addInventoryItem(item);

            // Go back to Login screen
            Intent intent = new Intent(this, InventoryMainActivity.class);

            startActivity(intent);
        }
    }

    public void Cancel(View view){
        // Go to InventoryMainActivity
        Intent intent = new Intent(this, InventoryMainActivity.class);

        startActivity(intent);
    }

    public void Click(View view){
        // Minimize keyboard
        InputMethodManager mgr = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        mgr.hideSoftInputFromWindow(mItemName.getWindowToken(), 0);
    }
}